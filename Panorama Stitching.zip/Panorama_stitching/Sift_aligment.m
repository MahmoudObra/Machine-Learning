function Sift_aligment

img1=imread('D:\materials\fourth year\second term\Vision\Assignments\Ass\New folder\2.png');
img2= imread('D:\materials\fourth year\second term\Vision\Assignments\Ass\New folder\3.png');
[matchLoc1 matchLoc2] = siftMatch(img1,img2);

[TFORM, inlier1 ,inlier2 ] = estimateGeometricTransform(matchLoc2,matchLoc1,'similarity');
figure; showMatchedFeatures(img1,img2,inlier1,inlier2);
title('matching inliers');

Rfixed = imref2d(size(img1));
[registered2, Rregistered] = imwarp(img2, TFORM,'FillValues', 255);
figure, imshowpair(img1,Rfixed,registered2,Rregistered,'blend');

end 