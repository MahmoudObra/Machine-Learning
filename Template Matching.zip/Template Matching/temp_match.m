function [] = temp_match()

  I = imread('G:\Year 4\2nd Term\Computer Vision\Labs\Task 1\car.jpg');

  I = I(1:200,1:200,:); 
  Igray = rgb2gray(I);     

  T = Igray(70:160,70:160);
  [Trow , Tcol]=size(T);
  
  imshow(I),title('El original')
  figure
  imshow(T),title('El template')
  figure
  
  CM = normxcorr2(T,Igray);
  
  imshow(CM)    
  
  [cmrow,cmcol]=size(CM);
  [maxval,imax]= max(abs(CM(:)));
  [ycoor,xcoor]= ind2sub(size(CM),imax(1));
  
  bestrow = ycoor - (Trow-1);
  bestcol = xcoor - (Tcol-1);
  
  figure, imshow(I);
  h = imrect(gca, [bestcol bestrow (Tcol-1) (Trow-1)]);
  
end

