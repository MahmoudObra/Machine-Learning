function [ y ] = Flip( x)
y = 1-x;

end

