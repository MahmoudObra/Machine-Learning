function [H] = Test( x )
 
load  'C:\Users\DELL\Desktop\MSE\Feature.mat' weights_vector;
%weight_vect = msse();
testedimage=imread(x);
%fliped_Image=1-testedimage;
%croped_Image = crop (fliped_Image);
matrinx=PreProcess(x);

temp= zeros(1,18);
index = 1;
for i=1:3
    for j=1:3
        var=matrinx{i,j};
        verctor = regionprops(var,'centroid');
        VectorOfCentroid = cat ( 1,verctor.Centroid);
        if size(VectorOfCentroid)==0
            temp(index : index+1)= [0,0];
        else
        temp(index : index+1)= VectorOfCentroid;
        index = index +2;
        end
    end
end

% load  'C:\Users\DELL\Desktop\MSE\Feature.mat' Z labels;


 temp = [temp,1];
 
 H = temp * weights_vector ;
 
 
 x= find(H>0);
 if (numel(x)==1)
    s = x-1;
 elseif (numel(x)==0)
     s = 'new class';
 else
     s='undetermined';
 end
 
   s
 

end


