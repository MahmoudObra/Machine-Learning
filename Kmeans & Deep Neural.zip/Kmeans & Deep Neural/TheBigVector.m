function [  ] = TheBigVector(  )
 y=zeros(100,18); % vector of centroid feature of the 100 sample image 
 List = dir('G:\Year 3 - 2nd Term\Materials\Pattern Recognation\Training Data\Pattern Recognition Data Set (0-9)');  % Read the directory of samples
 Folder = 'G:\Year 3 - 2nd Term\Materials\Pattern Recognation\Training Data\Pattern Recognition Data Set (0-9)\'; % string take samples directory to append
 index=1;
 labels={};  % kan commenttttttttttttttttttttt
 c=1; % counter
 for i=3:102
     path = strcat(Folder,List(i).name);
     labels{c}=List(i).name(1);   % lables vector carry the first char(number)of the name of the 100 sample 
     c=c+1;   % de kanet comment wel satr eli fo2eh kmaaaaaaaaaaaaaaaaan 
     y(i-2,index:index+17)=CEntriodForOnePic(path);  % function (centroid for one pic) gets centroid of sample images
     
 end
 
 save 'C:\Users\DELL\Desktop\K-Means\Feature.mat' y labels;
 
 

end

