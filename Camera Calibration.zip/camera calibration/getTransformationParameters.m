function X = getTransformationParameters(rwPoint,imgPoint,imgPoint2)


A = [];
Y = [];


for i=1:size(imgPoint,1)
    
    A = [A;rwPoint(i,1) , rwPoint(i,2), rwPoint(i,3),1,0, 0,0,0, -imgPoint(i,1)*rwPoint(i,1), -imgPoint(i,1)*rwPoint(i,2), -imgPoint(i,1)*rwPoint(i,3) ;...
    0, 0, 0, 0, rwPoint(i,1) , rwPoint(i,2), rwPoint(i,3),1, -imgPoint(i,2)*rwPoint(i,1), -imgPoint(i,2)*rwPoint(i,2), -imgPoint(i,2)*rwPoint(i,3)];
    
    % 12*11
end

X = pinv(A) * imgPoint2;  %11*1

end