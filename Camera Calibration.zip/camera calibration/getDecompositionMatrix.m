function decMatrix = getDecompositionMatrix(M)


%% get rotation in x direction
r = sqrt(M(3,3).^2 + M(3,2).^2);
c = M(3,3) / r;
s = M(3,2) / r;

Mx = M * [1 0 0; 0 c s; 0 -s c];

%% get rotation in y direction

r = sqrt(Mx(3,3).^2 + Mx(3,1).^2);
c = Mx(3,3) / r;
s = Mx(3,1) / r;

My = Mx * [c 0 s; 0 1 0; -s 0 c]

%% get rotation in z direction

r = sqrt(My(1,1).^2 + My(1,2).^2);
c = My(2,2) / r;
s = My(2,1) / r;

Mz = My * [c s 0; -s c 0; 0 0 1];

%%

decMatrix = Mz;


end