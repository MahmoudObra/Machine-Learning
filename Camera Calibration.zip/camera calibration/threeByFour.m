%appending 1 on 11*1  => become 12*1
%transform 3*4 => remove last column to be 3*3
function mat2 = threeByFour(mat)

mat2 = zeros(3,4);
counter = 0;

for i=1:3
    for j=1:4
        if(counter < 11)
            counter = counter + 1;
            mat2(i,j) = mat(counter,1);
        end
        
    end
end






end