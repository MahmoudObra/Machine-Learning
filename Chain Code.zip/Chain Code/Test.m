function num = Test(path)

In_img=imread(path);
O=Crop(Flip(In_img));  
  % imshow(Cimg);   
    s = regionprops(O,'centroid');
    center = cat(1,s.Centroid);          %calculate centroid
    FV=Chain(O,center);
    Matrix=load ('G:\Year 3 - 2nd Term\Materials\Pattern Recognation\Assignments\Assignment #2 (Chaincode)\Feature.mat');
    Matrix=Matrix.FM;
    minv=0;
    minindex=0;
    for i=1:100
    Start=((i-1)*256)+1;
    End=Start+255;
    submat=Matrix(Start:End,:);
    %Diff=sqrt(sum((FV-submat).^2));
    Diff=sum((FV-submat).^2);
    if i==1
        minv=Diff;
        minindex=i;
    end
    if Diff < minv
        minv=Diff;
        minindex=i;
    end
    
    if Diff == 0
        minv=Diff;
        minindex=i;
        break;
    end
    
    end
    if minindex >= 1 && minindex <=10
        num = 0;
    
    elseif minindex >= 11 && minindex <=20
        num = 1;
    
    elseif minindex >= 21 && minindex <=30
        num = 2;
    
    elseif minindex >= 31 && minindex <=40
        num = 3;
        
    elseif minindex >= 41 && minindex <=50
        num = 4;
        
    elseif minindex >= 51 && minindex <=60
        num = 5;
        
    elseif minindex >= 61 && minindex <=70
        num = 6;
        
   elseif minindex >= 71 && minindex <=80
        num = 7;
        
    elseif minindex >= 81 && minindex <=90
        num = 8;
        
    elseif minindex >= 91 && minindex <=100
        num = 9; 
    end
end
