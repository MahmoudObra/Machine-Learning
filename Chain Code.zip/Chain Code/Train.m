function [FM]=Train()

path='G:\Year 3 - 2nd Term\Materials\Pattern Recognation\Training Data\Pattern Recognition Data Set (0-9)\';   % path of images
images=dir('G:\Year 3 - 2nd Term\Materials\Pattern Recognation\Training Data\Pattern Recognition Data Set (0-9)\*.bmp');  

FM = [];   % feature matrix
for i=1:length(images)   
    imageName=images(i).name;    
    imageLabel=imageName(1:1); % the number in image
    fullpath=strcat(path,imageName);   
    img=imread(fullpath) ;  
    In_img = Crop(Flip(img));  

    s = regionprops(In_img,'centroid');
    center = cat(1,s.Centroid);          
    
    F = Chain(In_img,center);    
     FM=[FM;F];
    % if (i==1)         % nafs el klam eli 7assal foo2 da , hne3mlo fel label vector 
     %      Label_Vec= imageLabel;
      %  else
    % Label_Vec=horzcat(Label_Vec,imageLabel);  % bss horizontal msh vertical 
     %   end
    
     
end    

save 'G:\Year 3 - 2nd Term\Materials\Pattern Recognation\Assignments\Assignment #2 (Chaincode)\Feature.mat' FM ;
   
   %FM = FM
   %Label_Vec = Label_Vec
   
end